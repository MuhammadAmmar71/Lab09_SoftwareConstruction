package poet;

import static org.junit.Assert.*;

import org.junit.Test;

import java.io.File;
import java.io.IOException;

/**
 * Tests for GraphPoet.
 */
public class GraphPoetTest {

    @Test(expected = AssertionError.class)
    public void testAssertionsEnabled() {
        assert false; // Ensure assertions are enabled with VM argument: -ea
    }

    @Test
    public void testBasicPoemGeneration() throws IOException {
        GraphPoet poet = new GraphPoet(new File("test/poet/simple-corpus.txt"));
        String poem = poet.poem("Hello world");
        assertEquals("Hello bridge world", poem);
    }

    @Test
    public void testNoBridgeWords() throws IOException {
        GraphPoet poet = new GraphPoet(new File("test/poet/simple-corpus.txt"));
        String poem = poet.poem("Unrelated text");
        assertEquals("Unrelated text", poem);
    }

    @Test
    public void testEmptyInput() throws IOException {
        GraphPoet poet = new GraphPoet(new File("test/poet/simple-corpus.txt"));
        String poem = poet.poem("");
        assertEquals("", poem);
    }

    @Test
    public void testCaseInsensitivity() throws IOException {
        GraphPoet poet = new GraphPoet(new File("test/poet/simple-corpus.txt"));
        String poem = poet.poem("HELLO WORLD");
        assertEquals("HELLO bridge WORLD", poem);
    }

    @Test
    public void testSpecialCharacters() throws IOException {
        GraphPoet poet = new GraphPoet(new File("test/poet/special-characters.txt"));
        String poem = poet.poem("Hello! World?");
        assertEquals("Hello! bridge World?", poem);
    }

    @Test
    public void testBridgeWordsInMiddle() throws IOException {
        GraphPoet poet = new GraphPoet(new File("test/poet/multi-word-corpus.txt"));
        String poem = poet.poem("This is a test");
        assertEquals("This is a sound test", poem);
    }
}
