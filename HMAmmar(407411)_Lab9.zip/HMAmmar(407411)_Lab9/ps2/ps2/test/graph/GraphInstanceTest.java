/* Copyright (c) 2015-2016 MIT 6.005 course staff, all rights reserved.
 * Redistribution of original or derived work requires permission of course staff.
 */
package graph;

import static org.junit.Assert.*;

import java.util.Collections;

import org.junit.Test;

import java.util.Map;
import java.util.Set;

/**
 * Tests for instance methods of Graph.
 * 
 * <p>PS2 instructions: you MUST NOT add constructors, fields, or non-@Test
 * methods to this class, or change the spec of {@link #emptyInstance()}.
 * Your tests MUST only obtain Graph instances by calling emptyInstance().
 * Your tests MUST NOT refer to specific concrete implementations.
 */

//Testing strategy

// - testInitialVerticesEmpty(): test that a new graph has no vertices
 // - testAddVertex(): add vertices and check if they exist in the graph
 // - testAddDuplicateVertex(): add a vertex that already exists and check no duplication
 // - testSetEdge(): add edges and check if they exist with correct weights
 // - testRemoveVertex(): remove a vertex and verify it no longer exists
//- testSourcesAndTargets(): check sources and targets for directed edges

public abstract class GraphInstanceTest {

    // This abstract method should be implemented in subclasses to return a new, empty Graph<String> instance.
    protected abstract Graph<String> emptyInstance();

    // Test: A new graph should have no vertices.
    @Test
    public void testInitialVerticesEmpty() {
        Graph<String> graph = emptyInstance();
        assertTrue("Expected empty graph to have no vertices", graph.vertices().isEmpty());
    }

    // Test: Adding vertices and verifying their existence in the graph.
    @Test
    public void testAddVertex() {
        Graph<String> graph = emptyInstance();
        assertTrue("Expected vertex to be added successfully", graph.add("A"));
        assertTrue("Expected graph to contain vertex A", graph.vertices().contains("A"));
    }

    // Test: Adding a duplicate vertex should not create a duplicate.
    @Test
    public void testAddDuplicateVertex() {
        Graph<String> graph = emptyInstance();
        assertTrue("Expected vertex to be added successfully", graph.add("A"));
        assertFalse("Expected duplicate vertex addition to return false", graph.add("A"));
        assertEquals("Expected only one instance of vertex A", 1, graph.vertices().size());
    }

    // Test: Setting edges and verifying existence and weights.
    @Test
    public void testSetEdge() {
        Graph<String> graph = emptyInstance();
        graph.add("A");
        graph.add("B");

        assertEquals("Expected new edge weight to be set", 0, graph.set("A", "B", 5));
        assertEquals("Expected edge weight to be updated", 5, graph.set("A", "B", 10));
        assertEquals("Expected edge weight to be returned", 10, graph.set("A", "B", 0));

        // Edge should be removed when weight is set to 0.
        Map<String, Integer> targets = graph.targets("A");
        assertFalse("Expected edge to be removed after setting weight to 0", targets.containsKey("B"));
    }

    // Test: Removing a vertex and ensuring it's no longer in the graph.
    @Test
    public void testRemoveVertex() {
        Graph<String> graph = emptyInstance();
        graph.add("A");
        graph.add("B");
        graph.set("A", "B", 5);

        assertTrue("Expected vertex A to be removed successfully", graph.remove("A"));
        assertFalse("Expected vertex A to no longer exist", graph.vertices().contains("A"));
        assertTrue("Expected vertex B to still exist", graph.vertices().contains("B"));
    }

    // Test: Verifying sources and targets for directed edges.
    @Test
    public void testSourcesAndTargets() {
        Graph<String> graph = emptyInstance();
        graph.add("A");
        graph.add("B");
        graph.add("C");

        graph.set("A", "B", 3);
        graph.set("C", "B", 7);

        Map<String, Integer> sources = graph.sources("B");
        assertEquals("Expected two sources for vertex B", 2, sources.size());
        assertEquals("Expected source A with weight 3", Integer.valueOf(3), sources.get("A"));
        assertEquals("Expected source C with weight 7", Integer.valueOf(7), sources.get("C"));

        Map<String, Integer> targets = graph.targets("A");
        assertEquals("Expected one target for vertex A", 1, targets.size());
        assertEquals("Expected target B with weight 3", Integer.valueOf(3), targets.get("B"));
    }
}
