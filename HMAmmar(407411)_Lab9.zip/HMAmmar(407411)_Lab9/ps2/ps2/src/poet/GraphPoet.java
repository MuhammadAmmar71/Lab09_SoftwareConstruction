package poet;

import graph.Graph;
import java.io.*;
import java.nio.file.Files;
import java.util.*;

/**
 * GraphPoet implementation using a word affinity graph.
 */
public class GraphPoet {

    private final Graph<String> graph = Graph.empty();

    // Abstraction function:
    //   Represents the affinity graph of words derived from the corpus.
    // Representation invariant:
    //   All vertices and edges have non-null labels and weights >= 0.
    // Safety from rep exposure:
    //   graph is encapsulated and modified only internally.

    private void checkRep() {
        for (String vertex : graph.vertices()) {
            assert vertex != null;
            Map<String, Integer> targets = graph.targets(vertex);
            for (Map.Entry<String, Integer> entry : targets.entrySet()) {
                assert entry.getKey() != null;
                assert entry.getValue() >= 0;
            }
        }
    }

    /**
     * Constructor to build a word affinity graph from the given corpus.
     * @param corpus text file for the corpus
     * @throws IOException if file cannot be read
     */
    public GraphPoet(File corpus) throws IOException {
        List<String> lines = Files.readAllLines(corpus.toPath());
        String[] words = String.join(" ", lines).split("\\s+");
        for (int i = 0; i < words.length - 1; i++) {
            String word1 = words[i].toLowerCase();
            String word2 = words[i + 1].toLowerCase();
            graph.add(word1);
            graph.add(word2);
            int currentWeight = graph.set(word1, word2, 0);
            graph.set(word1, word2, currentWeight + 1);
        }
        checkRep();
    }

    /**
     * Generate a poem from the input string.
     * @param input string to transform into a poem
     * @return the generated poem
     */
    public String poem(String input) {
        String[] words = input.split("\\s+");
        if (words.length == 0) {
            return "";
        }

        StringBuilder result = new StringBuilder();

        for (int i = 0; i < words.length - 1; i++) {
            String word1 = words[i].toLowerCase();
            String word2 = words[i + 1].toLowerCase();
            result.append(words[i]).append(" ");
            String bridgeWord = findBridgeWord(word1, word2);
            if (bridgeWord != null) {
                result.append(bridgeWord).append(" ");
            }
        }
        result.append(words[words.length - 1]);
        return result.toString();
    }

    /**
     * Finds a bridge word with maximum weight between two words.
     */
    private String findBridgeWord(String word1, String word2) {
        Map<String, Integer> targetsFromWord1 = graph.targets(word1);
        String bestBridge = null;
        int maxWeight = 0;

        for (String bridge : targetsFromWord1.keySet()) {
            int weight1 = targetsFromWord1.getOrDefault(bridge, 0);
            int weight2 = graph.targets(bridge).getOrDefault(word2, 0);
            if (weight1 > 0 && weight2 > 0 && weight1 + weight2 > maxWeight) {
                bestBridge = bridge;
                maxWeight = weight1 + weight2;
            }
        }
        return bestBridge;
    }

    @Override
    public String toString() {
        return graph.toString();
    }
}
