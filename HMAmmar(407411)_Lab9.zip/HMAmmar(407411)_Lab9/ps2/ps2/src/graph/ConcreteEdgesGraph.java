package graph;

import java.util.*;

public class ConcreteEdgesGraph<L> implements Graph<L> {

    private final Set<L> vertices = new HashSet<>();
    private final List<Edge<L>> edges = new ArrayList<>();

    // Abstraction Function:
    // - vertices represents the set of vertices in the graph.
    // - edges represents the set of directed edges in the graph, where each edge contains a source, target, and weight.

    // Representation Invariant:
    // - Every vertex in the edges list must exist in the vertices set.
    // - All weights in edges are positive.

    // Safety from Rep Exposure:
    // - vertices and edges are private and final.
    // - Methods return new collections or unmodifiable views to prevent external modification.

    private void checkRep() {
        for (Edge<L> edge : edges) {
            assert vertices.contains(edge.getSource());
            assert vertices.contains(edge.getTarget());
            assert edge.getWeight() > 0;
        }
    }

    @Override
    public boolean add(L vertex) {
        if (vertices.add(vertex)) {
            checkRep();
            return true;
        }
        return false;
    }

    @Override
    public int set(L source, L target, int weight) {
        add(source);
        add(target);

        for (Edge<L> edge : edges) {
            if (edge.getSource().equals(source) && edge.getTarget().equals(target)) {
                int previousWeight = edge.getWeight();
                if (weight == 0) {
                    edges.remove(edge);
                } else {
                    edges.remove(edge);
                    edges.add(new Edge<>(source, target, weight));
                }
                checkRep();
                return previousWeight;
            }
        }

        if (weight > 0) {
            edges.add(new Edge<>(source, target, weight));
        }
        checkRep();
        return 0;
    }

    @Override
    public boolean remove(L vertex) {
        if (!vertices.contains(vertex)) return false;

        vertices.remove(vertex);
        edges.removeIf(edge -> edge.getSource().equals(vertex) || edge.getTarget().equals(vertex));
        checkRep();
        return true;
    }

    @Override
    public Set<L> vertices() {
        return Collections.unmodifiableSet(vertices);
    }

    @Override
    public Map<L, Integer> sources(L target) {
        Map<L, Integer> sources = new HashMap<>();
        for (Edge<L> edge : edges) {
            if (edge.getTarget().equals(target)) {
                sources.put(edge.getSource(), edge.getWeight());
            }
        }
        return sources;
    }

    @Override
    public Map<L, Integer> targets(L source) {
        Map<L, Integer> targets = new HashMap<>();
        for (Edge<L> edge : edges) {
            if (edge.getSource().equals(source)) {
                targets.put(edge.getTarget(), edge.getWeight());
            }
        }
        return targets;
    }

    @Override
    public String toString() {
        return "Vertices: " + vertices + ", Edges: " + edges;
    }
}

class Edge<L> {

    private final L source;
    private final L target;
    private final int weight;

    /**
     * Constructor for Edge
     * 
     * @param source the source vertex
     * @param target the target vertex
     * @param weight the weight of the edge
     * @throws IllegalArgumentException if weight is not positive
     */
    public Edge(L source, L target, int weight) {
        if (weight <= 0) {
            throw new IllegalArgumentException("Weight must be positive");
        }
        this.source = source;
        this.target = target;
        this.weight = weight;
        checkRep();
    }

    private void checkRep() {
        assert weight > 0;
    }

    public L getSource() {
        return source;
    }

    public L getTarget() {
        return target;
    }

    public int getWeight() {
        return weight;
    }

    @Override
    public String toString() {
        return source + " -> " + target + " (" + weight + ")";
    }
}
